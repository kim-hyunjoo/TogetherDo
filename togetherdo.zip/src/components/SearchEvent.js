const SearchEvent = () => {

}

export default SearchEvent;